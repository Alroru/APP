package es.studium.datospersonales;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button buttonGenerar,buttonLimpiar,buttonEspanol,buttonIngles;
    EditText editTextNombre,editTextApellidos,editTextEdad;
    Spinner spinnerEstadoCivil;
    RadioButton radioButtonHombre,radioButtonMujer;
    Switch switchHijos;
    TextView textViewDatosPersonales;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonGenerar =findViewById(R.id.buttonGenerar);
        buttonGenerar.setOnClickListener(this);
        buttonLimpiar=findViewById(R.id.buttonLimpiar);
        buttonLimpiar.setOnClickListener(this);
        buttonEspanol=findViewById(R.id.buttonEspanol);
        buttonEspanol.setOnClickListener(this);
        buttonIngles=findViewById(R.id.buttonIngles);
        buttonIngles.setOnClickListener(this);
        editTextNombre=findViewById(R.id.editTextNombre);
        editTextApellidos=findViewById(R.id.editTextApellidos);
        editTextEdad=findViewById(R.id.editTextEdad);
        textViewDatosPersonales=findViewById(R.id.textViewDatosPersonales);
        spinnerEstadoCivil=findViewById(R.id.spinnerEstadoCivil);
        radioButtonHombre=findViewById(R.id.radioButtonHombre);
        radioButtonMujer=findViewById(R.id.radioButtonMujer);
        switchHijos=findViewById(R.id.switchHijos);
    }

    @Override
    public void onClick(View view) {
        String genero;
        String edad = null;
        String hijos ;
        if(view.equals(buttonGenerar))
        {
            if(editTextEdad.getText().toString().equals("")||editTextApellidos.getText().toString().equals("")||editTextNombre.getText().toString().equals(""))
            {
                textViewDatosPersonales.setText("Error");

            }
            else {
                if (Integer.parseInt(editTextEdad.getText().toString()) >= 18) {
                    edad = " es mayor de edad";
                } else {
                    edad = " es menor de edad";
                }

                if (switchHijos.isChecked()) {
                    hijos = " tiene hijos";
                } else {
                    hijos = " no tiene hijos";
                }
                if (radioButtonHombre.isChecked()) {
                    genero = " es hombre";
                } else {
                    genero = " es mujer";
                }


                Toast.makeText(this, editTextApellidos.getText().toString() + "," + editTextNombre.getText().toString() + edad + ", es " + spinnerEstadoCivil.getSelectedItem() + hijos + genero, Toast.LENGTH_SHORT).show();
            }
        }

        else if (view.equals(buttonLimpiar))
        {
            textViewDatosPersonales.setText("");
            editTextNombre.setText("");
            editTextApellidos.setText("");
            editTextEdad.setText("");
        }
        else if (view.equals(buttonEspanol))
        {
            Toast.makeText(this,"ESPAÑOL", Toast.LENGTH_SHORT).show();
            Locale localizacion = new Locale("es","ES");
            Locale.setDefault(localizacion);
            Configuration config = new Configuration();
            config.locale = localizacion;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
            finish();
            startActivity(getIntent());
        }
        else if (view.equals(buttonIngles))
        {
            Toast.makeText(this,"ENGLISH", Toast.LENGTH_SHORT).show();
            Locale localizacion = new Locale("en","US");
            Locale.setDefault(localizacion);
            Configuration config = new Configuration();
            config.locale = localizacion;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
            finish();
            startActivity(getIntent());
        }
    }
}