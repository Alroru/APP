package es.studium.datospersonales;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button buttonGenerar,buttonLimpiar,buttonEspanol,buttonIngles;
    EditText editTextNombre,editTextApellidos,editTextEdad;
    Spinner spinnerEstadoCivil;
    RadioButton radioButtonHombre,radioButtonMujer;
    Switch switchHijos;
    TextView textViewDatosPersonales;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonGenerar =findViewById(R.id.buttonGenerar);
        buttonGenerar.setOnClickListener(this);
        buttonLimpiar=findViewById(R.id.buttonLimpiar);
        buttonLimpiar.setOnClickListener(this);
        buttonEspanol=findViewById(R.id.buttonEspanol);
        buttonEspanol.setOnClickListener(this);
        buttonIngles=findViewById(R.id.buttonIngles);
        buttonIngles.setOnClickListener(this);
        editTextNombre=findViewById(R.id.editTextNombre);
        editTextApellidos=findViewById(R.id.editTextApellidos);
        editTextEdad=findViewById(R.id.editTextEdad);
        textViewDatosPersonales=findViewById(R.id.textViewDatosPersonales);
    }

    @Override
    public void onClick(View view) {
        int numero;
        String edad;
        String texto="";
        if(view==buttonGenerar)
        {
            numero=Integer.parseInt(editTextEdad.getText().toString().trim());
        if(numero>=18)
        {
            edad=" es mayor de edad";
        }
        else
        {
           edad=" es menor de edad";
        }
        texto=editTextApellidos.getText().toString()+","+editTextNombre.getText().toString()+ edad;
        textViewDatosPersonales.setText(""+texto);
        if(texto.equals(""))
        {
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
        }
        }
        else if (view==buttonLimpiar)
        {
            textViewDatosPersonales.setText("");
            editTextNombre.setText("");
            editTextApellidos.setText("");
            editTextEdad.setText("");
        }
    }
}